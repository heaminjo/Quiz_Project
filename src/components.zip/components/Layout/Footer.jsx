import FooterComp from "./FooterStyle";

export default function Footer() {
  return (
    <FooterComp>
      <h1>Footer 입니다.</h1>
    </FooterComp>
  );
}
