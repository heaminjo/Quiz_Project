import styled from "styled-components";

const FooterComp = styled.footer`
  width: 100%;
  height: 200px;
  background-color: #000;
  color: #fff;
`;
export default FooterComp;
