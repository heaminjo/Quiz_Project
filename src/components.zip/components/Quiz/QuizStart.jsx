export default function QuizStart(quiz) {
  console.log(quiz);
  return <></>;
}
